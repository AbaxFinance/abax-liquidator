--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:CrexFFfaydp6iFs4tr4tyQ==$L+ClAWC3l8vvpprn84TJT5P5px0E1dTD1IQjBIMK66I=:Klav6XxU5enmUIPGGPO26qK5C5ryTYad2OKvNLEHw9I=';

--
-- User Configurations
--








--
-- PostgreSQL database cluster dump complete
--

