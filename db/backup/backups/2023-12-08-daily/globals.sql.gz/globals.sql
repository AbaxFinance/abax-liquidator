--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:Jw2OkiCWP57vDQDCUl7W1w==$51cMsSIi/+WyW6JGN5wiHLGUvdpVutGH1glBsR7nGiw=:4wNm28iPQp9p2rZ3db5YT4/VWc51by10JzP27Uv8Sns=';

--
-- User Configurations
--








--
-- PostgreSQL database cluster dump complete
--

