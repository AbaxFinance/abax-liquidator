--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Debian 16.1-1.pgdg120+1)
-- Dumped by pg_dump version 16.1 (Ubuntu 16.1-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: postgres
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: postgres
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: postgres
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: analyzedBlocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."analyzedBlocks" (
    "blockNumber" integer NOT NULL
);


ALTER TABLE public."analyzedBlocks" OWNER TO postgres;

--
-- Name: asset_prices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.asset_prices (
    name character varying(48) NOT NULL,
    address character(48) NOT NULL,
    "currentPriceE8" character varying(128) NOT NULL,
    "anchorPriceE8" character varying(128) NOT NULL,
    "updateTimestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.asset_prices OWNER TO postgres;

--
-- Name: events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.events (
    id integer NOT NULL,
    "contractName" character varying(32) NOT NULL,
    "contractAddress" character(48) NOT NULL,
    name character varying(48) NOT NULL,
    "blockTimestamp" timestamp with time zone NOT NULL,
    "blockNumber" integer NOT NULL,
    "blockHash" character(66) NOT NULL,
    data jsonb NOT NULL,
    hash character(66) NOT NULL
);


ALTER TABLE public.events OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_seq OWNER TO postgres;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: lp_marketRules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."lp_marketRules" (
    id integer NOT NULL,
    "assetRules" json
);


ALTER TABLE public."lp_marketRules" OWNER TO postgres;

--
-- Name: lp_reserveDatas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."lp_reserveDatas" (
    id integer NOT NULL,
    address character(48) NOT NULL,
    "maximalTotalDeposit" character varying(256),
    "maximalTotalDebt" character varying(256),
    "minimalCollateral" character varying(128) NOT NULL,
    "minimalDebt" character varying(128) NOT NULL,
    "depositIndexE18" character varying(128) NOT NULL,
    "debtIndexE18" character varying(128) NOT NULL,
    "indexesUpdateTimestamp" timestamp with time zone NOT NULL,
    "debtFeeE6" character varying(128) NOT NULL,
    "depositFeeE6" character varying(128) NOT NULL,
    "decimalMultiplier" character varying(128) NOT NULL,
    activated boolean NOT NULL,
    freezed boolean NOT NULL,
    "totalDeposit" character varying NOT NULL,
    "currentDepositRateE18" character varying(128) NOT NULL,
    "totalDebt" character varying(128) NOT NULL,
    "currentDebtRateE18" character varying(128) NOT NULL,
    "interestRateModel" jsonb
);


ALTER TABLE public."lp_reserveDatas" OWNER TO postgres;

--
-- Name: lp_trackingData; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."lp_trackingData" (
    address character(48) NOT NULL,
    "updatePriority" integer NOT NULL,
    "helathFactor" double precision NOT NULL,
    "updateAtLatest" timestamp with time zone NOT NULL,
    "updateTimestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."lp_trackingData" OWNER TO postgres;

--
-- Name: lp_userConfigs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."lp_userConfigs" (
    address character(48) NOT NULL,
    deposits character varying(128) NOT NULL,
    collaterals character varying(128) NOT NULL,
    borrows character varying(128) NOT NULL,
    "marketRuleId" integer NOT NULL,
    "updateTimestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."lp_userConfigs" OWNER TO postgres;

--
-- Name: lp_userDatas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."lp_userDatas" (
    address character(48) NOT NULL,
    "reserveAddress" character(48) NOT NULL,
    deposit character varying(256) NOT NULL,
    debt character varying(256) NOT NULL,
    "appliedCumulativeDepositIndexE18" character varying(256) NOT NULL,
    "appliedCumulativeDebtIndexE18" character varying(256) NOT NULL,
    "updateTimestamp" timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."lp_userDatas" OWNER TO postgres;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: postgres
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
1	1b14dcd72f9940bbc69c15d19dbfd1fafabcfdba9d666171a5dc32bf5f3742e8	1702048551549
\.


--
-- Data for Name: analyzedBlocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."analyzedBlocks" ("blockNumber") FROM stdin;
48710358
48710360
48710361
48710362
48710363
48710359
48710368
48710369
48710370
48710371
48710364
48710366
48710365
48710367
48710372
48710375
48710376
48710377
48710373
48710374
48710378
48710379
48710380
48710381
48710382
48710383
48710384
48710385
48710387
48710386
48710390
48710391
48710392
48710393
48710389
48710388
48710394
48710397
48710398
48710399
48710400
48710401
48710402
48710396
48710395
48710404
48710405
48710406
48710407
48710408
48710403
48710409
48710410
48710411
48710412
48710413
48710414
48710418
48710419
48710420
48710415
48710421
48710416
48710417
48710425
48710426
48710427
48710423
48710424
48710422
48710428
48710430
48710431
48710432
48710433
48710429
48710434
48710435
48710439
48710436
48710440
48710437
48710438
48710441
48710442
48710446
48710443
48710444
48710447
48710448
48710449
48710451
48710450
48710445
48710453
48710454
48710455
48710456
48710452
48710457
48710460
48710461
48710462
48710463
48710464
48710465
48710459
48710458
48710466
48710467
48710468
48710469
48710471
48710470
48710472
48710473
48710474
48710475
48710476
48710477
48710480
48710481
48710482
48710483
48710478
48710479
48710487
48710488
48710489
48710484
48710486
48710485
48710490
48710491
48710492
48710493
48710494
48710495
48710496
48710497
48710500
48710501
48710498
48710499
48710502
48710503
48710507
48710506
48710505
48710508
48710504
48710509
48710510
48710514
48710511
48710512
48710515
48710516
48710517
48710520
48710513
48710521
48710518
48710519
\.


--
-- Data for Name: asset_prices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.asset_prices (name, address, "currentPriceE8", "anchorPriceE8", "updateTimestamp") FROM stdin;
BTC	5CJCSzTY2wZQaDp9PrzC1LsVfTEp9sGBHcAY3vjv9JLakfX9	4387980000000.0005	4387980000000.0005	2023-12-08 15:25:30+00
USDC	5GXDPgrjJC7cyr9B1jCm5UqLGuephaEKGoAeHKfodB3TVghP	99986000	99986000	2023-12-08 15:25:30+00
ETH	5DgMoQHDKSJryNGR4DXo5H267Hmnf9ph5ZMLPXBtPxcZfN3P	236101000000.00003	236101000000.00003	2023-12-08 15:25:30+00
DOT	5EwcHvcGBC9jnVzmPJUzwgZJLxUkrWCzzZfoqpjZ45o9C9Gh	660940000	660940000	2023-12-08 15:25:30+00
DAI	5ELYqHS8YZ2hAEnCiqGJg8Ztc6JoFFKHpvgUbuz9oW9vc5at	100089999.99999999	100089999.99999999	2023-12-08 15:25:30+00
AZERO	5CLLmNswXre58cuz6hBnyscpieFYUyqq5vwvopiW3q41SSYF	129450000	129450000	2023-12-08 15:25:30+00
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.events (id, "contractName", "contractAddress", name, "blockTimestamp", "blockNumber", "blockHash", data, hash) FROM stdin;
\.


--
-- Data for Name: lp_marketRules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."lp_marketRules" (id, "assetRules") FROM stdin;
0	"[{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0e09c0\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"107ac0\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"9c40\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0e7ef0\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"100590\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"61a8\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0b71b0\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"1312d0\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"01e848\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0b71b0\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"1312d0\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"01e848\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"099cf0\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"15aae0\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"030d40\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0aae60\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"13d620\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"0249f0\\"}}]"
1	"[{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0ef420\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"0f9060\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"2710\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0f1b30\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"0f6950\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"1388\\"}},null]"
2	"[null,null,{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0dbba0\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"10c8e0\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"c350\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0dbba0\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"10c8e0\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"c350\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0c3500\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"124f80\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"0186a0\\"}},{\\"collateralCoefficientE6\\":{\\"rawNumber\\":\\"0cf850\\"},\\"borrowCoefficientE6\\":{\\"rawNumber\\":\\"118c30\\"},\\"penaltyE6\\":{\\"rawNumber\\":\\"0124f8\\"}}]"
\.


--
-- Data for Name: lp_reserveDatas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."lp_reserveDatas" (id, address, "maximalTotalDeposit", "maximalTotalDebt", "minimalCollateral", "minimalDebt", "depositIndexE18", "debtIndexE18", "indexesUpdateTimestamp", "debtFeeE6", "depositFeeE6", "decimalMultiplier", activated, freezed, "totalDeposit", "currentDepositRateE18", "totalDebt", "currentDebtRateE18", "interestRateModel") FROM stdin;
5	5DcB6aPqy4MxmtvJED6Mfy1PXyUxWViwgKds9sMXx5mWFajQ	1000000000000000000000000000	1000000000000000000000000000	2000	1000	1000000000000000000	1000000000000000000	2023-12-08 15:25:32+00	0	0	1000000000000	t	f	0	0	0	0	"[{\\"rawNumber\\":\\"0493e0\\"},{\\"rawNumber\\":\\"07a120\\"},{\\"rawNumber\\":\\"1e8480\\"},{\\"rawNumber\\":\\"3d0900\\"},{\\"rawNumber\\":\\"989680\\"},{\\"rawNumber\\":\\"05f5e100\\"},{\\"rawNumber\\":\\"11e1a300\\"}]"
0	5F4YGe2yR3R7xQaVQrWz9KokDtT71mcp5qzTADCAxuEyAzcp	\N	\N	2000000	1000000	1000000000000000000	1000000000000000000	2023-12-08 15:25:32+00	0	0	1000000	t	f	0	0	0	0	"[{\\"rawNumber\\":\\"0493e0\\"},{\\"rawNumber\\":\\"07a120\\"},{\\"rawNumber\\":\\"1e8480\\"},{\\"rawNumber\\":\\"3d0900\\"},{\\"rawNumber\\":\\"989680\\"},{\\"rawNumber\\":\\"05f5e100\\"},{\\"rawNumber\\":\\"11e1a300\\"}]"
1	5E4r2RXd7aczvbwLvVj3CcKe2vtxduVnpkJP1DztnE1jLAKx	\N	\N	2000	1000	1000000000000000000	1000000000000000000	2023-12-08 15:25:32+00	0	0	1000000	t	f	0	0	0	0	"[{\\"rawNumber\\":\\"0493e0\\"},{\\"rawNumber\\":\\"07a120\\"},{\\"rawNumber\\":\\"1e8480\\"},{\\"rawNumber\\":\\"3d0900\\"},{\\"rawNumber\\":\\"989680\\"},{\\"rawNumber\\":\\"05f5e100\\"},{\\"rawNumber\\":\\"11e1a300\\"}]"
2	5GDDKd4iKDBXseSXCqfraWxECM5nWpZmLNTVuGdpcm2WZX2w	\N	\N	2000	1000	1000000079209216868	1000000627330987798	2023-12-08 15:25:32+00	0	0	1000000000000000000	t	f	15240000000663863566279	5361	1680000000000000000000	48634	"[{\\"rawNumber\\":\\"0493e0\\"},{\\"rawNumber\\":\\"07a120\\"},{\\"rawNumber\\":\\"1e8480\\"},{\\"rawNumber\\":\\"3d0900\\"},{\\"rawNumber\\":\\"989680\\"},{\\"rawNumber\\":\\"05f5e100\\"},{\\"rawNumber\\":\\"11e1a300\\"}]"
3	5GG4WWB9V5dUaoTuZ1BsCVpAjU27XyCAiZtXFm5fqRu6r4fY	\N	\N	2000	1000	1000000000000000000	1000000000000000000	2023-12-08 15:25:32+00	0	0	100000000	t	f	0	0	0	0	"[{\\"rawNumber\\":\\"0493e0\\"},{\\"rawNumber\\":\\"07a120\\"},{\\"rawNumber\\":\\"1e8480\\"},{\\"rawNumber\\":\\"3d0900\\"},{\\"rawNumber\\":\\"989680\\"},{\\"rawNumber\\":\\"05f5e100\\"},{\\"rawNumber\\":\\"11e1a300\\"}]"
4	5FwJkGXsRHctjDbDSw6mU6ZvGgsY8PKGWdEEp1M2VcYox7Mh	\N	\N	2000	1000	1000000002619892845	1000000116771117568	2023-12-08 15:25:32+00	0	0	1000000000000	t	f	18600000000000872454	224	420000000000000000	9962	"[{\\"rawNumber\\":\\"0493e0\\"},{\\"rawNumber\\":\\"07a120\\"},{\\"rawNumber\\":\\"1e8480\\"},{\\"rawNumber\\":\\"3d0900\\"},{\\"rawNumber\\":\\"989680\\"},{\\"rawNumber\\":\\"05f5e100\\"},{\\"rawNumber\\":\\"11e1a300\\"}]"
\.


--
-- Data for Name: lp_trackingData; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."lp_trackingData" (address, "updatePriority", "helathFactor", "updateAtLatest", "updateTimestamp") FROM stdin;
\.


--
-- Data for Name: lp_userConfigs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."lp_userConfigs" (address, deposits, collaterals, borrows, "marketRuleId", "updateTimestamp") FROM stdin;
\.


--
-- Data for Name: lp_userDatas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."lp_userDatas" (address, "reserveAddress", deposit, debt, "appliedCumulativeDepositIndexE18", "appliedCumulativeDebtIndexE18", "updateTimestamp") FROM stdin;
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: postgres
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 1, true);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.events_id_seq', 1, false);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: lp_userDatas address_reserve_idx; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."lp_userDatas"
    ADD CONSTRAINT address_reserve_idx PRIMARY KEY (address, "reserveAddress");


--
-- Name: analyzedBlocks analyzedBlocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."analyzedBlocks"
    ADD CONSTRAINT "analyzedBlocks_pkey" PRIMARY KEY ("blockNumber");


--
-- Name: asset_prices asset_prices_address_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asset_prices
    ADD CONSTRAINT asset_prices_address_unique UNIQUE (address);


--
-- Name: asset_prices asset_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asset_prices
    ADD CONSTRAINT asset_prices_pkey PRIMARY KEY (name);


--
-- Name: events events_hash_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_hash_unique UNIQUE (hash);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: lp_marketRules lp_marketRules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."lp_marketRules"
    ADD CONSTRAINT "lp_marketRules_pkey" PRIMARY KEY (id);


--
-- Name: lp_reserveDatas lp_reserveDatas_address_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."lp_reserveDatas"
    ADD CONSTRAINT "lp_reserveDatas_address_unique" UNIQUE (address);


--
-- Name: lp_reserveDatas lp_reserveDatas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."lp_reserveDatas"
    ADD CONSTRAINT "lp_reserveDatas_pkey" PRIMARY KEY (id);


--
-- Name: lp_trackingData lp_trackingData_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."lp_trackingData"
    ADD CONSTRAINT "lp_trackingData_pkey" PRIMARY KEY (address);


--
-- Name: lp_userConfigs lp_userConfigs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."lp_userConfigs"
    ADD CONSTRAINT "lp_userConfigs_pkey" PRIMARY KEY (address);


--
-- Name: address_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX address_id_index ON public."lp_reserveDatas" USING btree (address, id);


--
-- Name: address_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX address_idx ON public."lp_userConfigs" USING btree (address);


--
-- Name: name_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX name_idx ON public.asset_prices USING btree (name);


--
-- PostgreSQL database dump complete
--

