--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:dKHkG6EzMTucjcs6jNmU6Q==$AA9ccwsvhI74wvrIj904qN4qaZG8oAFDjEgl3im6mlY=:x6mB6zS6qFke8gra+weYCBRWdyYGgkDiEI3kCmgY1T4=';

--
-- User Configurations
--








--
-- PostgreSQL database cluster dump complete
--

